import java.util.Arrays;
import java.util.Stack;

public class DFS {
    private Scenario scene;
    private Stack<State> movesTracker;

    private int searched;
    private int discovered;

    boolean[] visited;

    DFS(Scenario scene) {
        this.scene = scene;
        this.movesTracker = new Stack<>();
        this.visited = new boolean[scene.getMapWidth() * scene.getMapHeight()];
        searched = 0;
        discovered = 0;
        Arrays.fill(visited, false);
    }

    public void search(State state) {
        movesTracker.push(state);
        int loopCount = 0;
        while (!movesTracker.empty()) {
            state = movesTracker.pop();
            searched++;
            visited[scene.getMapWidth() * state.getY() + state.getX()] = true;
            int[] currentCoord = {state.getX(), state.getY()};
            if (scene.isSolved(currentCoord)) {
                break;
            }

            if (scene.stateMovableLeft(state)) {
                State next = new State(state, state.getX() - 1, state.getY());
                if (!visited[scene.getMapWidth() * next.getY() + next.getX()]) {
                    movesTracker.push(next);
                    discovered++;
                }
            }
            if (scene.stateMovableDown(state)) {
                State next = new State(state, state.getX(), state.getY() + 1);
                if (!visited[scene.getMapWidth() * next.getY() + next.getX()]) {
                    movesTracker.push(next);
                    discovered++;
                }
            }
            if (scene.stateMovableUp(state)) {
                State next = new State(state, state.getX(), state.getY() - 1);
                if (!visited[scene.getMapWidth() * next.getY() + next.getX()]) {
                    movesTracker.push(next);
                    discovered++;
                }
            }
            if (scene.stateMovableRight(state)) {
                State next = new State(state, state.getX() + 1, state.getY());
                if (!visited[scene.getMapWidth() * next.getY() + next.getX()]) {
                    movesTracker.push(next);
                    discovered++;
                }
            }
        }
        scene.displaySolution("DFS algorithm",state, searched, discovered);
    }
}
