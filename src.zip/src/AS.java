import java.util.*;

public class AS {
    private Scenario scene;
    private PriorityQueue<State> pq;
    private int searched;
    private int discovered;

    AS(Scenario scene) {
        this.scene = scene;
        pq = new PriorityQueue<>();
        searched = 0;
        discovered = 0;
    }

    private static List<State> reconstructPath(State state) {
        List<State> path = new ArrayList<>();
        while (state != null) {
            path.add(state);
            state = state.getParent();
        }
        Collections.reverse(path);
        return path;
    }

    public void search(State start) {
        int[][] targets = scene.getTargetsCoord();
        Random random = new Random();
        int[] goalCoord = targets[random.nextInt(targets.length)];
        State goalState = new State(null, goalCoord[0], goalCoord[1], 0);

        // Print the goal state
//        System.out.println("Goal state: " + goalState.getX() + ", " + goalState.getY());
        State result = null;
        List<State> closedSet = new ArrayList<>();
        if (start != null) {
            start.setCost(0);
            start.setHCost(manhattanDistance(start, goalState));
            start.setCost(start.getHCost());
//            System.out.println("Start state: " + start.getX() + ", " + start.getY() + "\n" + "Start Search\n");
            pq.offer(start);

            while (!pq.isEmpty()) {
                // Define the best state to move to
                State current = pq.poll();
                searched++;
                // Print the selected state and its parent detail
//                if (current.getParent() != null) {
//                    System.out.println("Selected state's parent: " + current.getParent().getX() + ", " + current.getParent().getY());
//                } else {
//                    System.out.println("Selected state is start state");
//                }
//                System.out.println("Selected state: " + current.getX() + ", " + current.getY());


                int[] currentCoord = {current.getX(), current.getY()};
                if (scene.isSolved(currentCoord)) {
                    result = current;
                    break;
                }

                // add State
                closedSet.add(current);

                // Check all possible move: Left, right, top or bottom
                // If a state is not moved on, add that state to the priority queue for polling in the next loop
                if (scene.stateMovableRight(current)) {
                    int nextX = current.getX() + 1;
                    int nextY = current.getY();
                    State nextState = new State(current, nextX, nextY);
                    int tentativeGCost = current.getGCost() + 1;
                    nextState.setGCost(tentativeGCost);
                    int nextStateHCost = manhattanDistance(nextState, goalState);
                    nextState.setHCost(nextStateHCost);
                    int nextStateCost = tentativeGCost + nextStateHCost;
                    nextState.setCost(nextStateCost);
                    if (!closedSet.contains(nextState)) {
                        pq.offer(nextState);
                        discovered++;
//                        System.out.println("Right cell: " + nextState.getX() + ", " + nextState.getY() + " is movable. Cost: " + nextStateCost);
                    }
                }

                if (scene.stateMovableLeft(current)) {
                    int nextX = current.getX() - 1;
                    int nextY = current.getY();
                    State nextState = new State(current, nextX, nextY);
                    int tentativeGCost = current.getGCost() + 1;
                    nextState.setGCost(tentativeGCost);
                    int nextStateHCost = manhattanDistance(nextState, goalState);
                    nextState.setHCost(nextStateHCost);
                    int nextStateCost = tentativeGCost + nextStateHCost;
                    nextState.setCost(nextStateCost);
                    if (!closedSet.contains(nextState)) {
                        pq.offer(nextState);
                        discovered++;
//                        System.out.println("Left cell: " + nextState.getX() + ", " + nextState.getY() + " is movable. Cost: " + nextStateCost);
                    }
                }

                if (scene.stateMovableUp(current)) {
                    int nextX = current.getX();
                    int nextY = current.getY() - 1;
                    State nextState = new State(current, nextX, nextY);
                    int tentativeGCost = current.getGCost() + 1;
                    nextState.setGCost(tentativeGCost);
                    int nextStateHCost = manhattanDistance(nextState, goalState);
                    nextState.setHCost(nextStateHCost);
                    int nextStateCost = tentativeGCost + nextStateHCost;
                    nextState.setCost(nextStateCost);
                    if (!closedSet.contains(nextState)) {
                        pq.offer(nextState);
                        discovered++;
//                        System.out.println("Up cell: " + nextState.getX() + ", " + nextState.getY() + " is movable. Cost: " + nextStateCost);
                    }
                }

                if (scene.stateMovableDown(current)) {
                    int nextX = current.getX();
                    int nextY = current.getY() + 1;
                    State nextState = new State(current, nextX, nextY);
                    int tentativeGCost = current.getGCost() + 1;
                    nextState.setGCost(tentativeGCost);
                    int nextStateHCost = manhattanDistance(nextState, goalState);
                    nextState.setHCost(nextStateHCost);
                    int nextStateCost = tentativeGCost + nextStateHCost;
                    nextState.setCost(nextStateCost);
                    if (!closedSet.contains(nextState)) {
                        pq.offer(nextState);
                        discovered++;
//                        System.out.println("Down cell: " + nextState.getX() + ", " + nextState.getY() + " is movable. Cost: " + nextStateCost);
                    }
                }
            }
            scene.displaySolution("A* algorithm",result, searched, discovered);
        }

    }

    private static int manhattanDistance(State a, State b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }
}
