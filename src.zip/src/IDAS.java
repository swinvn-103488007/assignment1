import java.util.*;

public class IDAS {
    private final Scenario scene;
    private final Stack<State> stack;
    private final boolean[][] visited;
    private final PriorityQueue<State> prunedState;
    private int searched;
    private int discovered;

    IDAS(Scenario scene) {
        this.scene = scene;
        stack = new Stack<>();
        visited = new boolean[scene.getMapWidth()][scene.getMapHeight()];
        prunedState = new PriorityQueue<>();
        searched = 0;
        discovered = 0;
    }

    public void search(State initialState) {
        int[][] targets = scene.getTargetsCoord();
        Random rand = new Random();
        int[] goalCoord = targets[rand.nextInt(targets.length)];
        State goalState = new State(null, goalCoord[0], goalCoord[1], 0);
        initialState.setCost(0, manhattanDistance(initialState, goalState));

        // Set threshold for pruning
        int threshosld = initialState.getCost();
        stack.push(initialState);
        State result = null;

        while (!stack.isEmpty()) {
            State currentState = stack.pop();
            visited[currentState.getX()][currentState.getY()] = true;
            searched++;
            int[] currentCoord = {currentState.getX(), currentState.getY()};
            if (scene.isSolved(currentCoord)) {
                result = currentState;
                break;
            }
            State nextRightState, nextLeftState, nextUpState, nextDownState;
            ArrayList<State> possibleNextStates = new ArrayList<>();
            if (scene.stateMovableRight(currentState) && !visited[currentState.getX() + 1][currentState.getY()]) {
                nextRightState = new State(currentState, currentState.getX() + 1, currentState.getY());
                nextRightState.setCost(currentState.getGCost() + 1, manhattanDistance(nextRightState, goalState));
                discovered++;
                if (nextRightState.getCost() < threshosld) {
                    possibleNextStates.add(nextRightState);
                } else {
                    prunedState.offer(nextRightState);
                }
            }

            if (scene.stateMovableLeft(currentState) && !visited[currentState.getX() - 1][currentState.getY()]) {
                nextLeftState = new State(currentState, currentState.getX() - 1, currentState.getY());
                nextLeftState.setCost(currentState.getGCost() + 1, manhattanDistance(nextLeftState, goalState));
                if (nextLeftState.getCost() < threshosld) {
                    possibleNextStates.add(nextLeftState);
                } else {
                    prunedState.offer(nextLeftState);
                }
            }

            if (scene.stateMovableUp(currentState) && !visited[currentState.getX()][currentState.getY() - 1]) {
                nextUpState = new State(currentState, currentState.getX(), currentState.getY() - 1);
                nextUpState.setCost(currentState.getGCost() + 1, manhattanDistance(nextUpState, goalState));
                discovered++;
                if (nextUpState.getCost() < threshosld) {
                    possibleNextStates.add(nextUpState);
                } else {
                    prunedState.offer(nextUpState);
                }
            }

            if (scene.stateMovableDown(currentState) && !visited[currentState.getX()][currentState.getY() + 1]) {
                nextDownState = new State(currentState, currentState.getX(), currentState.getY() + 1);
                nextDownState.setCost(currentState.getGCost() + 1, manhattanDistance(nextDownState, goalState));
                discovered++;
                if (nextDownState.getCost() < threshosld) {
                    possibleNextStates.add(nextDownState);
                } else {
                    prunedState.offer(nextDownState);
                }
            }

            if (possibleNextStates.size() > 0) {
                Collections.sort(possibleNextStates);
                threshosld = possibleNextStates.get(0).getCost();
                for (int i = possibleNextStates.size() - 1; i >= 0; i--) {
                    stack.push(possibleNextStates.get(i));
                }
            }
            if (stack.isEmpty()) {
                stack.push(prunedState.poll());
            }
        }
        scene.displaySolution("Iterative deepening A*",result, searched, discovered);
    }

    private static int manhattanDistance(State a, State b) {
        return Math.abs(a.getX() - b.getX()) + Math.abs(a.getY() - b.getY());
    }
}
