import java.util.ArrayList;
import java.util.LinkedList;

public class BFS {
    private Scenario scene;
    private LinkedList<State> frontier;
    private int searched;
    private int discovered;

    BFS(Scenario scene) {
        this.scene = scene;
        frontier = new LinkedList<>();
        searched = 0;
        discovered = 0;
    }
    public void search(State initial) {
        if (initial != null) {
            frontier.add(initial);
        }
        State current = null;
        while (!frontier.isEmpty()) {
            current = frontier.removeFirst();
            searched++;
            int[] currentCoord = {current.getX(), current.getY()};
            if (scene.isSolved(currentCoord)) {
                break;
            }
            addMovesToFrontier(scene.determinePossibleMoves(current));
        }
        scene.displaySolution("BFS algorithm",current, searched, discovered);
    }

    public void addMovesToFrontier(ArrayList<State> possibleMoves) {
        frontier.addAll(possibleMoves);
        discovered++;
    }
}
